package com.example.myapplication;

import java.util.ArrayList;
import java.util.HashMap;

public class Contacts {

    public static ArrayList<HashMap<String,String>> values = new ArrayList<HashMap<String,String>>();

}
